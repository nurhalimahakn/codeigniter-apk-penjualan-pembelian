<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Proyek Tingkat II</title>

    <!-- Bootstrap core CSS -->
    <link href="<?php echo base_url('coming/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet')?>"/>

    <!-- Custom fonts for this template -->
    <link href="<?php echo base_url('https://fonts.googleapis.com/coming/css?family=Raleway:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Lora:400,400i,700,700i" rel="stylesheet')?>"/>

    <!-- Custom styles for this template -->
    <link href="<?php echo base_url('coming/css/business-casual.min.css" rel="stylesheet')?>"/>

</head>

<body>

    <h1 class="site-heading text-center text-white d-none d-lg-block">
        <span class="site-heading-upper text-primary mb-3">Memenuhi Kebetuhan sehari - hari Anda!!!</span>
        <span class="site-heading-lower">UD MURNI</span>
    </h1>

    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark py-lg-4" id="mainNav">
      <div class="container">
          <?php if ($this->session->userdata('LEVEL') == 'admin'){ ?>
          <div class="collapse navbar-collapse" id="navbarResponsive">
              <ul class="navbar-nav mx-auto">
                  <li class="nav-item active px-lg-4">
                    <li class="<?php if(isset($active_dashboard)){echo $active_dashboard ;}?>">
                        <a style="background: #333; color: #fff"; href="<?php echo site_url('dashboard')?>"><i class="nav-link text-uppercase text-expanded"></i><h5>Dashboard</h5></a>
                    </li>
                </li>
                <li class="nav-item active px-lg-4">
                    <li class="<?php if(isset($active_penjualan)){echo $active_penjualan ;}?>">
                        <a style="background: #333; color: #fff"; href="<?php echo site_url('penjualan')?>"><i class="nav-link text-uppercase text-expanded"></i><h5>Penjualan</h5></a>
                        <span class="sr-only">(current)</span>
                    </li>
                </li>
                <li class="nav-item active px-lg-4">
                    <li class="<?php if(isset($active_pembelian)){echo $active_pembelian ;}?>">
                        <a style="background: #333; color: #fff"; href="<?php echo site_url('pembelian')?> "><i class="nav-link text-uppercase text-expanded"></i><h5>Pembelian</h5></a>
                        <span class="sr-only">(current)</span>
                    </li>
                </li>
                <li class="nav-item active px-lg-4">
                    <li class="<?php if(isset($active_laporan)){echo $active_laporan ;}?>">
                        <a style="background: #333; color: #fff"; href="<?php echo site_url('laporan')?>"><i class="nav-link text-uppercase text-expanded"></i><h5>Laporan</h5></a>
                        <span class="sr-only">(current)</span>
                    </li>
                </li>
                <li class="nav-item active px-lg-4">
                    <li class="<?php if(isset($active_master)){echo $active_master ;}?>">
                        <a style="background: #333; color: #fff"; href="<?php echo site_url('master')?>"><i class="nav-link text-uppercase text-expanded"></i><h5>Master Data</h5></a>
                        <span class="sr-only">(current)</span>
                    </li>
                </li>
                <li class="nav-item active px-lg-4">
                    <li><a href="<?php echo site_url('login/logout')?>" style="background: #333; color: #ff0";><i class="nav-link text-uppercase text-expanded"></i><h5>Logout</h5></a></li>
                    <span class="sr-only">(current)</span>
                </li>
            </ul>
        </div>
    </div>
    <br>
    <?php } else { ?>

      <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav mx-auto">
              <li class="nav-item active px-lg-4">
                <li class="<?php if(isset($active_dashboard)){echo $active_dashboard ;}?>">
                    <a style="background: #333; color: #fff"; href="<?php echo site_url('dashboard')?>"><i class="icon-barcode"></i><h5>Dashboard</h5></a>
                    <span class="sr-only">(current)</span>
                </li>
            </li>
            <li class="nav-item active px-lg-4">
                <li class="<?php if(isset($active_penjualan)){echo $active_penjualan ;}?>">
                    <a style="background: #333; color: #fff"; href="<?php echo site_url('penjualan')?>"><i class="icon-barcode"></i><h5>Penjualan</h5></a>
                    <span class="sr-only">(current)</span>
                </li>
            </li>
            <li class="nav-item active px-lg-4">
                <li class="<?php if(isset($active_laporan)){echo $active_laporan ;}?>">
                    <a style="background: #333; color: #fff"; href="<?php echo site_url('laporan')?>"><i class="icon-file"></i><h5>Laporan</h5></a>
                    <span class="sr-only">(current)</span>
                </li>
            </li>
            <li class="nav-item active px-lg-4">
                <li><a href="<?php echo site_url('login/logout')?>" style="background: #333; color: #ff0"><i class="icon-white icon-remove-sign"></i> <h5>Logout</h5></a></li>
                <span class="sr-only">(current)</span>
            </li>
        </ul>
    </div>
</div>
</div>
<br>

<?php } ?>

</ul>
</div>
</div>
</nav>


<!-- Bootstrap core JavaScript -->
<script src="<?php echo base_url('coming/vendor/jquery/jquery.min.js')?>"/></script>
<script src="<?php echo base_url('coming/vendor/bootstrap/js/bootstrap.bundle.min.js')?>"/></script>

</body>

</html>











































