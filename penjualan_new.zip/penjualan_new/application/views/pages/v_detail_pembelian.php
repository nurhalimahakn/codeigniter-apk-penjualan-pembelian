<!--========================= Content Wrapper ==============================-->
<div class="container">

    <div class="well">
        <h4 class="alert alert-info" style="text-align: center">Keterangan</h4>
        <div class="row-fluid">
            <?php if(isset($dt_pembelian)){
                foreach($dt_pembelian as $row){
                    ?>
                    <div class="span6">
                        <dl class="dl-horizontal">
                            <dt style="background: #333; color: #fff";>Kode Pembelian :</dt>
                            <dd style="background: #333; color: #fff";><?php echo $row->kd_pembelian?></dd>
                            <br/>
                            <dt style="background: #333; color: #fff";>Tanggal Pembelian :</dt>
                            <dd style="background: #333; color: #fff";><?php echo date("d M Y",strtotime($row->tanggal_pembelian));?></dd>
                            <br/>
                            <dt style="background: #333; color: #fff";>Total Harga :</dt>
                            <dd style="background: #333; color: #fff";><strong><u><?= currency_format($row->total_harga); ?></u></strong></dd>
                        </dl>
                    </div>
                    <div class="span6">
                        <dl class="dl-horizontal">
                            <dt style="background: #333; color: #fff";>Suplier :</dt>
                            <dd style="background: #333; color: #fff";><?php echo $row->nm_suplier?></dd>
                            <br/>
                            <dt style="background: #333; color: #fff";>Alamat :</dt>
                            <dd style="background: #333; color: #fff";><?php echo $row->alamat?></dd>
                            <br/>
                            <dt style="background: #333; color: #fff";>Email :</dt>
                            <dd style="background: #333; color: #fff";><?php echo $row->email?></dd>
                            <br/>
                        </dl>
                    </div>
                <?php }
            }
            ?>
        </div>
    </div>


    <div class="well">
        <h4 style="background: #333; color: #fff"; class="alert alert-info" style="text-align: center"> Daftar Barang</h4>
        <div class="row-fluid">
            <table class="table table-bordered table-striped">
                <thead>
                <tr>
                    <th style="background: #333; color: #fff";>No</th>
                    <th style="background: #333; color: #fff";>Kode Barang</th>
                    <th style="background: #333; color: #fff";>Nama Barang</th>
                    <th style="background: #333; color: #fff";>Qty</th>
                    <th style="background: #333; color: #fff";>Harga</th>
                </tr>
                </thead>
                <tbody>
                <?php
                $no=1;
                if(isset($barang_jual)){
                    foreach($barang_jual as $row ){
                        ?>
                        <tr>
                            <td style="background: #333; color: #fff";><?php echo $no++; ?></td>
                            <td style="background: #333; color: #fff";><?php echo $row->kd_barang?></td>
                            <td style="background: #333; color: #fff";><?php echo $row->nm_barang?></td>
                            <td style="background: #333; color: #fff";><?php echo $row->qty?></td>
                            <td style="background: #333; color: #fff";><?php echo currency_format($row->harga)?></td>
                        </tr>
                    <?php }
                }
                ?>
                </tbody>
            </table>

            <div class="form-actions">
                <a href="<?php echo site_url('penjualan')?>" class="btn btn-inverse">
                    <i style="background: #333; color: #fff"; class="icon-circle-arrow-left icon-white"></i> Back
                </a>
            </div>
        </div>
    </div>


</div>



