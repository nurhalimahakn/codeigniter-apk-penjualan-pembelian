
<table class="table table-bordered table-striped">
    <thead>
    <tr>
        <th style="background: #333; color: #fff";>No</th>
        <th style="background: #333; color: #fff";>Kode Suplier</th>
        <th style="background: #333; color: #fff";>Nama Suplier</th>
        <th style="background: #333; color: #fff";>Alamat</th>
        <th style="background: #333; color: #fff";>Email</th>
        <th class="span2">
            <a style="background: #333; color: #fff"; href="#modalAddSuplier" class="btn btn-mini btn-block btn-inverse" data-toggle="modal">
                <i class="icon-plus-sign icon-white" style="background: #333; color: #fff";></i> Tambah Data
            </a>
        </th>
    </tr>
    </thead>
    <tbody>
    <?php
    $no=1;
    if(isset($data_suplier)){
        foreach($data_suplier as $row){
            ?>
            <tr>
                <td style="background: #333; color: #fff";><?php echo $no++; ?></td>
                <td style="background: #333; color: #fff";><?php echo $row->kd_suplier; ?></td>
                <td style="background: #333; color: #fff";><?php echo $row->nm_suplier; ?></td>
                <td style="background: #333; color: #fff";><?php echo $row->alamat; ?></td>
                <td style="background: #333; color: #fff";><?php echo $row->email; ?></td>
                <td>
                    <a style="background: #333; color: #fff"; class="btn btn-mini" href="#modalEditSuplier<?php echo $row->kd_suplier?>" data-toggle="modal"><i class="icon-pencil" style="background: #333; color: #fff";></i> Edit</a>
                    <a style="background: #333; color: #fff"; class="btn btn-mini" href="<?php echo site_url('master/hapus_suplier/'.$row->kd_suplier);?>"
                       onclick="return confirm('Anda yakin?')"> <i class="icon-remove" ></i> Hapus</a>
                </td>
            </tr>

        <?php }
    }
    ?>

    </tbody>
</table>

<!-- ============ MODAL ADD PELANGGAN =============== -->
<div id="modalAddSuplier" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        <h3 id="myModalLabel" style="background: #333; color: #fff";>Tambah Data Suplier</h3>
    </div>
    <form class="form-horizontal" method="post" action="<?php echo site_url('master/tambah_suplier')?>">
        <div class="modal-body">
            <div class="control-group">
                <label class="control-label" style="background: #333; color: #fff";>Kode Suplier</label>
                <div class="controls">
                    <input name="kd_suplier" style="background: #333; color: #fff"; type="text" placeholder="input kode Suplier">
                </div>
            </div>

            <div class="control-group">
                <label class="control-label" style="background: #333; color: #fff";>Nama Suplier</label>
                <div class="controls">
                    <input name="nm_suplier" type="text" placeholder="Input Nama Suplier...">
                </div>
            </div>

            <div class="control-group">
                <label class="control-label" style="background: #333; color: #fff"; >Alamat</label>
                <div class="controls">
                    <input name="alamat" style="background: #333; color: #fff"; type="text" placeholder="Input Alamat...">
                </div>
            </div>

            <div class="control-group">
                <label class="control-label" style="background: #333; color: #fff";>Email</label>
                <div class="controls">
                    <input name="email" style="background: #333; color: #fff"; type="email" placeholder="Input Email..." >
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn" data-dismiss="modal" aria-hidden="true" style="background: #333; color: #fff";>Close</button>
            <button class="btn btn-primary" style="background: #333; color: #fff";>Save changes</button>
        </div>
    </form>
</div>

<!-- ============ MODAL EDIT PELANGGAN =============== -->
<?php
if(isset($data_suplier)){
    foreach($data_suplier as $row){
        ?>
        <div id="modalEditSuplier<?php echo $row->kd_suplier?>" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-header">
                <button type="button" style="background: #333; color: #fff"; class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <h3 id="myModalLabel" style="background: #333; color: #fff";>Edit Data Suplier</h3>
            </div>
            <form class="form-horizontal" style="background: #333; color: #fff"; method="post" action="<?php echo site_url('master/edit_suplier')?>">
                <div class="modal-body">
                    <div class="control-group">
                        <label class="control-label" style="background: #333; color: #fff";>Kode Suplier</label>
                        <div class="controls">
                            <input name="kd_suplier" style="background: #333; color: #fff"; type="text" value="<?php echo $row->kd_suplier; ?>" readonly>
                        </div>
                    </div>

                    <div class="control-group">
                        <label class="control-label" style="background: #333; color: #fff";>Nama Suplier</label>
                        <div class="controls">
                            <input name="nm_suplier" style="background: #333; color: #fff"; type="text" value="<?php echo $row->nm_suplier; ?>">
                        </div>
                    </div>

                    <div class="control-group">
                        <label class="control-label" style="background: #333; color: #fff"; >Alamat</label>
                        <div class="controls">
                            <input name="alamat" style="background: #333; color: #fff"; type="text" value="<?php echo $row->alamat; ?>">
                        </div>
                    </div>

                    <div class="control-group">
                        <label class="control-label" style="background: #333; color: #fff";>Email</label>
                        <div class="controls">
                            <input name="email" style="background: #333; color: #fff"; type="email" value="<?php echo $row->email; ?>">
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn" data-dismiss="modal" aria-hidden="true" style="background: #333; color: #fff">Close</button>
                    <button type="submit" class="btn btn-primary" style="background: #333; color: #fff">Save changes</button>
                </div>
            </form>
        </div>
    <?php }
}
?>