<!--================ Content Wrapper===========================================-->
<table class="table table-bordered table-striped">
    <thead>
    <tr>
        <th style="background: #333; color: #fff";>No</th>
        <th style="background: #333; color: #fff";>Tanggal</th>
        <th style="background: #333; color: #fff";>Kode Penjualan</th>
        <th style="background: #333; color: #fff";>Jumlah</th>
        <th style="background: #333; color: #fff";>Total Harga</th>
        <th class="span3">
            <a style="background: #333; color: #fff"; href="<?php echo site_url('penjualan/pages_tambah_penjualan')?>" class="btn btn-mini btn-block btn-inverse" data-toggle="modal">
                <i class="icon-plus-sign icon-white"></i> Tambah Data
            </a>
        </th>
    </tr>
    </thead>
    <tbody>
    <?php
    $no=1;
    if(isset($data_penjualan)){
        foreach($data_penjualan as $row){
            ?>
            <tr class="gradeX">
                <td style="background: #333; color: #fff";><?php echo $no++; ?></td>
                <td style="background: #333; color: #fff";><?php echo date("d M Y",strtotime($row->tanggal_penjualan)); ?></td>
                <td style="background: #333; color: #fff";><?php echo $row->kd_penjualan; ?></td>
                <td style="background: #333; color: #fff";><?php echo $row->qty; ?> Items</td>
                <td style="background: #333; color: #fff";><?php echo currency_format($row->total_harga); ?></td>
                <td>
                    <a style="background: #333; color: #fff"; class="btn btn-mini" href="<?php echo site_url('penjualan/detail_penjualan/'.$row->kd_penjualan)?>">
                        <i class="icon-eye-open"></i> View</a>
                    <a style="background: #333; color: #fff"; class="btn btn-mini" href="<?php echo site_url('penjualan/hapus/'.$row->kd_penjualan)?>"
                       onclick="return confirm('Anda Yakin ?');">
                        <i class="icon-trash"></i> Hapus</a>
                    <a style="background: #333; color: #fff"; class="btn btn-mini btnPrint" href="<?php echo site_url('cetak/print_penjualan/'.$row->kd_penjualan)?>">
                        <i class="icon-print"></i> Print</a>
                </td>
            </tr>
        <?php }
    }
    ?>

    </tbody>
</table>



