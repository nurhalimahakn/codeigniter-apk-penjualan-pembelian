
<table class="table table-bordered table-striped">
    <thead>
    <tr>
        <th style="background: #333; color: #fff";>No</th>
        <th style="background: #333; color: #fff";>Tanggal</th>
        <th style="background: #333; color: #fff";>Kode Penjualan</th>
        <th style="background: #333; color: #fff";>Nama Pelanggan</th>
        <th style="background: #333; color: #fff";>Total Harga</th>
    </tr>
    </thead>
    <tbody>
    <?php
    $no=1;
    if(isset($dt_result)){
        foreach($dt_result as $data){
            ?>
            <tr class="gradeX">
                <td style="background: #333; color: #fff";><?php echo $no++; ?></td>
                <td style="background: #333; color: #fff";><?php echo date("d M Y",strtotime($data->tanggal_penjualan)); ?></td>
                <td style="background: #333; color: #fff";><?php echo $data->kd_penjualan; ?></td>
                <td style="background: #333; color: #fff";><?php echo $data->nm_pelanggan; ?></td>
                <td style="background: #333; color: #fff";><?php echo currency_format($data->total_harga); ?></td>
            </tr>
                
        <?php }
    }
    ?>
    </tbody>
</table>

<td colspan="4" style="text-align: center; background: #ff0"><strong>Total Seluruh Penjualan</strong></td>
<!-- <td style="background: #333; color: #ff0";><?= currency_format($data->total_all)?></td>
<td> -->
<?php
$kd_penjualan = 'kd_penjualan';
echo currency_format($kd_penjualan=$this->uri->segment("SELECT sum(total_harga) as total_all FROM tbl_penjualan_header WHERE tanggal_penjualan"));
?>
</td>
<hr/>

<button class="btn pull-right" onclick="print()">
    <i class="icon-print"></i> Print
</button>