
<table class="table table-bordered table-striped">
    <thead>
    <tr>
        <th style="background: #333; color: #fff";>No</th>
        <th style="background: #333; color: #fff";>Kode Pegawai</th>
        <th style="background: #333; color: #fff";>User ID</th>
        <th style="background: #333; color: #fff";>Nama Pegawai</th>
        <th style="background: #333; color: #fff";>Level</th>
        <th class="span2">
            <a style="background: #333; color: #fff"; href="#modalAddPegawai" class="btn btn-mini btn-block btn-inverse" data-toggle="modal">
                <i class="icon-plus-sign icon-white" style="background: #333; color: #fff";></i> Tambah Data
            </a>

<!--            <a href="#" class="btn btn-mini btn-block btn-inverse disabled" data-toggle="modal">-->
<!--                <i class="icon-plus-sign icon-white"></i> Tambah Data-->
<!--            </a>-->
        </th>
    </tr>
    </thead>
    <tbody>

    <?php
    $no=1;
    if(isset($data_pegawai)){
        foreach($data_pegawai as $row){
            ?>
            <tr>
                <td style="background: #333; color: #fff";><?php echo $no++; ?></td>
                <td style="background: #333; color: #fff";><?php echo $row->kd_pegawai; ?></td>
                <td style="background: #333; color: #fff";><?php echo $row->username; ?></td>
                <td style="background: #333; color: #fff";><?php echo $row->nama; ?></td>
                <td style="background: #333; color: #fff";><?php echo $row->level; ?></td>

                <td>
                    <a style="background: #333; color: #fff"; class="btn btn-mini" href="#modalEditPegawai<?php echo $row->kd_pegawai?>" data-toggle="modal"><i class="icon-pencil"></i> Edit</a>
                    <a style="background: #333; color: #fff"; class="btn btn-mini" href="<?php echo site_url('master/hapus_pegawai/'.$row->kd_pegawai);?>"
                       onclick="return confirm('Anda yakin?')"> <i class="icon-remove" ></i> Hapus</a>

<!--                    <a class="btn btn-mini disabled" href="#" data-toggle="modal"><i class="icon-pencil"></i> Edit</a>-->
<!--                    <a class="btn btn-mini disabled" href="#"> <i class="icon-remove"></i> Hapus</a>-->
                </td>

            </tr>

        <?php }
    }
    ?>

    </tbody>
</table>

<!-- ============ MODAL ADD PEGAWAI =============== -->
<div id="modalAddPegawai"  class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        <h3 id="myModalLabel" style="background: #333; color: #fff";>Tambah Data Pegawai</h3>
    </div>
    <form class="form-horizontal" style="background: #333; color: #fff"; method="post" action="<?php echo site_url('master/tambah_pegawai')?>">
        <div class="modal-body">
            <div class="control-group">
                <label class="control-label" style="background: #333; color: #fff";>Kode Pegawai</label>
                <div class="controls">
                    <input name="kd_pegawai" style="background: #333; color: #fff"; type="text" value="<?php echo $kd_pegawai; ?>" readonly>
                </div>
            </div>

            <div class="control-group">
                <label class="control-label" style="background: #333; color: #fff";>User ID</label>
                <div class="controls">
                    <input name="username" style="background: #333; color: #fff"; type="text" required>
                </div>
            </div>

            <div class="control-group">
                <label class="control-label" style="background: #333; color: #fff";>Password</label>
                <div class="controls">
                    <input name="password" style="background: #333; color: #fff"; type="password" required>
                </div>
            </div>

            <hr/>

            <div class="control-group">
                <label class="control-label" style="background: #333; color: #fff";>Nama Pegawai</label>
                <div class="controls">
                    <input name="nama" style="background: #333; color: #fff"; type="text">
                </div>
            </div>

            <div class="control-group">
                <label class="control-label" style="background: #333; color: #fff";>Level</label>
                <div class="controls">
                    <select name="level" id="level">
                        <option value="" style="background: #333; color: #fff";> = Pilih Level Akses = </option>
                        <option value="pegawai" style="background: #333; color: #fff";>Pegawai</option>
                        <option value="admin" style="background: #333; color: #fff";>Admin</option>
                    </select>
                </div>
            </div>
        </div>

        <div class="modal-footer">
            <button class="btn" data-dismiss="modal" aria-hidden="true" style="background: #333; color: #fff";>Close</button>
            <button class="btn btn-primary" style="background: #333; color: #fff";>Save</button>
        </div>
    </form>
</div>


<!-- ============ MODAL EDIT PEGAWAI =============== -->
<?php
if (isset($data_pegawai)){
    foreach($data_pegawai as $row){
        ?>
        <div id="modalEditPegawai<?php echo $row->kd_pegawai?>" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-header">
                <button type="button" style="background: #333; color: #fff"; class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <h3 id="myModalLabel" style="background: #333; color: #fff";>Edit Data Pegawai</h3>
            </div>

            <form class="form-horizontal" style="background: #333; color: #fff"; method="post" action="<?php echo site_url('master/edit_pegawai')?>">
                <div class="modal-body">
                    <div class="control-group">
                        <label class="control-label" style="background: #333; color: #fff";>Kode Pegawai</label>
                        <div class="controls">
                            <input name="kd_pegawai" style="background: #333; color: #fff"; type="text" value="<?php echo $row->kd_pegawai; ?>" class="uneditable-input" readonly="true">
                        </div>
                    </div>

                    <div class="control-group">
                        <label class="control-label" style="background: #333; color: #fff";>User ID</label>
                        <div class="controls">
                            <input name="username" style="background: #333; color: #fff"; type="text" value="<?php echo $row->username?>" required>
                        </div>
                    </div>

                    <div class="control-group">
                        <label class="control-label" style="background: #333; color: #fff";>Password</label>
                        <div class="controls">
                            <input name="password" style="background: #333; color: #fff"; type="password" required>
                        </div>
                    </div>

                    <hr/>

                    <div class="control-group">
                        <label class="control-label" style="background: #333; color: #fff";>Nama Pegawai</label>
                        <div class="controls">
                            <input name="nama" style="background: #333; color: #fff"; type="text" value="<?php echo $row->nama?>">
                        </div>
                    </div>

                    <div class="control-group">
                        <label class="control-label" style="background: #333; color: #fff";>Level</label>
                        <div class="controls">
                            <select name="level" id="level">
                                <?php if($row->level == 'admin'){?>
                                    <option value="admin" selected="selected" style="background: #333; color: #fff";>Admin</option>
                                <?php }else{ ?>
                                    <option value="pegawai" style="background: #333; color: #fff";>Pegawai</option>
                                <?php }?>
                            </select>
                        </div>
                    </div>
                </div>

                <div class="modal-footer">
                    <button class="btn" data-dismiss="modal" aria-hidden="true" style="background: #333; color: #fff";>Close</button>
                    <button class="btn btn-primary" style="background: #333; color: #fff";>Save</button>
                </div>
            </form>
        </div>
    <?php }
}
?>