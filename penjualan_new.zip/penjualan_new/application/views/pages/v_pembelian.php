
<table class="table table-bordered table-striped">
    <thead>
    <tr>
        <th style="background: #333; color: #fff";>No</th>
        <th style="background: #333; color: #fff";>Tanggal</th>
        <th style="background: #333; color: #fff";>Kode Pembelian</th>
        <th style="background: #333; color: #fff";>Jumlah</th>
        <th style="background: #333; color: #fff";>Total Harga</th>
        <th class="span3">
            <a style="background: #333; color: #fff";  href="<?php echo site_url('pembelian/pages_tambah_pembelian')?>" class="btn btn-mini btn-block btn-inverse" data-toggle="modal">
                <i class="icon-plus-sign icon-white"></i> Tambah Data
            </a>
        </th>
    </tr>
    </thead>
    <tbody>
    <?php
    $no=1;
    if(isset($data_pembelian)){
        foreach($data_pembelian as $row){
            ?>
            <tr class="gradeX">
                <td style="background: #333; color: #fff";><?php echo $no++; ?></td>
                <td style="background: #333; color: #fff";><?php echo date("d M Y",strtotime($row->tanggal_pembelian)); ?></td>
                <td style="background: #333; color: #fff";><?php echo $row->kd_pembelian; ?></td>
                <td style="background: #333; color: #fff";><?php echo $row->jumlah; ?> Items</td>
                <td style="background: #333; color: #fff";><?php echo currency_format($row->total_harga); ?></td>
                <td>
                    <a style="background: #333; color: #fff"; class="btn btn-mini" href="<?php echo site_url('pembelian/detail_pembelian/'.$row->kd_pembelian)?>">
                        <i  class="icon-eye-open"></i> View</a>
                    <a i style="background: #333; color: #fff"; class="btn btn-mini" href="<?php echo site_url('pembelian/hapus/'.$row->kd_pembelian)?>"
                       onclick="return confirm('Anda Yakin ?');">
                        <i class="icon-trash"></i> Hapus</a>
                    <a style="background: #333; color: #fff";  class="btn btn-mini btnPrint" href="<?php echo site_url('cetak/print_pembelian/'.$row->kd_pembelian)?>">
                        <i class="icon-print"></i> Print</a>
                </td>
            </tr>
        <?php }
    }
    ?>

    </tbody>
</table>



