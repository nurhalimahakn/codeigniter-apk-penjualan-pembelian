
<table class="table table-bordered table-striped">
    <thead>
    <tr>
        <th style="background: #333; color: #fff";>No</th>
        <th style="background: #333; color: #fff";>Kode Barang</th>
        <th style="background: #333; color: #fff";>Nama Barang</th>
        <th style="background: #333; color: #fff";>Stok</th>
        <th style="background: #333; color: #fff";>Harga</th>
        <th class="span2">
            <a style="background: #333; color: #fff"; href="#modalAddBarang" class="btn btn-mini btn-block btn-inverse" data-toggle="modal">
                <i class="icon-plus-sign icon-white" style="background: #333; color: #fff";></i> Tambah Data
            </a>
        </th>
    </tr>
    </thead>
    <tbody>

    <?php
    $no=1;
    if(isset($data_barang)){
    foreach($data_barang as $row){
    ?>
    <tr>
        <td style="background: #333; color: #fff";><?php echo $no++; ?></td>
        <td style="background: #333; color: #fff";><?php echo $row->kd_barang; ?></td>
        <td style="background: #333; color: #fff";><?php echo $row->nm_barang; ?></td>
        <td style="background: #333; color: #fff";><?php echo $row->stok; ?></td>
        <td style="background: #333; color: #fff";><?php echo currency_format($row->harga);?></td>
        <td>
            <a style="background: #333; color: #fff"; class="btn btn-mini" href="#modalEditBarang<?php echo $row->kd_barang?>" data-toggle="modal"><i  class="icon-pencil" style="background: #333; color: #fff";></i> Edit</a>
            <a style="background: #333; color: #fff"; class="btn btn-mini" href="<?php echo site_url('master/hapus_barang/'.$row->kd_barang);?>"
               onclick="return confirm('Anda yakin?')"> <i  class="icon-remove"></i> Hapus</a>
        </td>
    </tr>

    <?php }
    }
    ?>

    </tbody>
</table>


<!-- ============ MODAL ADD BARANG =============== -->
<div id="modalAddBarang" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        <h3 id="myModalLabel" style="background: #333; color: #fff";>Tambah Data Barang</h3>
    </div>
    <form class="form-horizontal" style="background: #333; color: #fff"; method="post" action="<?php echo site_url('master/tambah_barang')?>">
        <div class="modal-body">
            <div class="control-group">
                <label class="control-label" style="background: #333; color: #fff";>Kode Barang</label>
                <div class="controls">
                    <input name="kd_barang" style="background: #333; color: #fff" type="text" value="<?php echo $kd_barang; ?>" readonly>
                </div>
            </div>

            <div class="control-group">
                <label class="control-label" style="background: #333; color: #fff";>Nama Barang</label>
                <div class="controls">
                    <input name="nm_barang" style="background: #333; color: #fff"; type="text" placeholder="Input Nama Barang...">
                </div>
            </div>

            <div class="control-group">
                <label class="control-label" style="background: #333; color: #fff"; >Stok</label>
                <div class="controls">
                    <input name="stok" style="background: #333; color: #fff"; type="text" placeholder="Input Stok...">
                </div>
            </div>

            <div class="control-group">
                <label class="control-label" style="background: #333; color: #fff";>Harga</label>
                <div class="controls">
                    <input name="harga" style="background: #333; color: #fff"; type="text" placeholder="Input Harga...">
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn" data-dismiss="modal" aria-hidden="true" style="background: #333; color: #fff";>Close</button>
            <button type="submit" class="btn btn-primary" style="background: #333; color: #fff";>Save</button>
        </div>
    </form>
</div>

<!-- ============ MODAL EDIT BARANG =============== -->
<?php
if (isset($data_barang)){
    foreach($data_barang as $row){
        ?>
        <div id="modalEditBarang<?php echo $row->kd_barang?>" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <h3 id="myModalLabel" style="background: #333; color: #fff";>Edit Data Barang</h3>
            </div>
            <form class="form-horizontal" style="background: #333; color: #fff"; method="post" action="<?php echo site_url('master/edit_barang')?>">
                <div class="modal-body">
                    <div class="control-group">
                        <label class="control-label" style="background: #333; color: #fff";>Kode Barang</label>
                        <div class="controls">
                            <input style="background: #333; color: #fff"; name="kd_barang" type="text" value="<?php echo $row->kd_barang;?>" readonly>
                        </div>
                    </div>

                    <div class="control-group">
                        <label class="control-label" style="background: #333; color: #fff";>Nama Barang</label>
                        <div class="controls">
                            <input name="nm_barang" style="background: #333; color: #fff"; type="text" value="<?php echo $row->nm_barang;?>" >
                        </div>
                    </div>

                    <div class="control-group">
                        <label class="control-label" style="background: #333; color: #fff";>Stok</label>
                        <div class="controls">
                            <input name="stok" style="background: #333; color: #fff"; type="text" value="<?php echo $row->stok;?>">
                        </div>
                    </div>

                    <div class="control-group">
                        <label class="control-label" style="background: #333; color: #fff";>Harga</label>
                        <div class="controls">
                            <input name="harga" style="background: #333; color: #fff"; type="text" value="<?php echo $row->harga;?>">
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn" data-dismiss="modal" aria-hidden="true" style="background: #333; color: #fff";>Close</button>
                    <button type="submit" class="btn btn-primary" style="background: #333; color: #fff";>Update</button>
                </div>
            </form>
        </div>
    <?php }
}
?>